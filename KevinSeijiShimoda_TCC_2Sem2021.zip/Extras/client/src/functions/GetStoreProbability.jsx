import Axios from "axios";

export var getStoreProbability = function (cost, wantedChampion, othersChampions, level, callback) {
    Axios.post('http://localhost:3001/api/storeProbability', {
        cost: cost,
        wantedChampion: wantedChampion,
        othersChampions: othersChampions,
        level: level

    }).then((response) => {

        callback(response.data)
    })
}

export default getStoreProbability;