import Axios from "axios";

export var getAllCostProbabilities = function (callback) {
    Axios.get('http://localhost:3001/api/getAllCostProbabilities').then((response) => {
        
        callback(response.data.costProbability.data);
      
        
    })
}

export default getAllCostProbabilities;