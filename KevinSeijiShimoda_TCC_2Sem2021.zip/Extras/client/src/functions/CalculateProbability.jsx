import getStoreProbability from "./GetStoreProbability";
import getRollsProbability from "./GetRollsProbability";

export var calculateProbability = function (cost, wantedChampion, othersChampions, level, gold, callback) {
    

    getStoreProbability(cost, wantedChampion, othersChampions, level, function(storeProbability){
        getRollsProbability(storeProbability, gold, function(response){
            callback(response*100);
        })
    })


}

export default calculateProbability;