import Axios from "axios";

export var getRollsProbability = function (storeProbability, gold, callback) {
    Axios.post('http://localhost:3001/api/rollsProbability', {
        storeProbability: storeProbability,
        gold: gold

    }).then((response) => {

        callback(response.data)
    })
}

export default getRollsProbability;