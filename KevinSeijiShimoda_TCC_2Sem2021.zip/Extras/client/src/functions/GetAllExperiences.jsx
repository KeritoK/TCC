import Axios from "axios";

export var getAllExperiences = function (callback) {
    Axios.get('http://localhost:3001/api/getAllExperiences').then((response) => {
        
        callback(response.data.experience.data);
      
        
    })
}

export default getAllExperiences;