import Axios from "axios";

export var getExperience = function (level, callback) {
    Axios.post('http://localhost:3001/api/getExperience', {
        level: level

    }).then((response) => {
        
        callback(response.data)
    })
}

export default getExperience;