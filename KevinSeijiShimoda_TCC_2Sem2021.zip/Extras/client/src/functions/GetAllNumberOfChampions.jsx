import Axios from "axios";

export var getAllNumberOfChampions = function (callback) {
    Axios.get('http://localhost:3001/api/getAllNumberOfChampions').then((response) => {
        
        callback(response.data.numberOfChampions.data);
      
        
    })
}

export default getAllNumberOfChampions;