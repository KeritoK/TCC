import Axios from "axios";

export var getNumberOfChampions = function (cost, callback) {
    Axios.post('http://localhost:3001/api/getNumberOfChampions', {
        cost: cost

    }).then((response) => {
        
        callback(response.data)
    })
}

export default getNumberOfChampions;