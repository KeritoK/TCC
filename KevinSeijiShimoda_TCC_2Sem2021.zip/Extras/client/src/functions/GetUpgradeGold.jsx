import Axios from "axios";

export var getUpgradeGold = function (level, xp, callback) {
    Axios.post('http://localhost:3001/api/upgradeGold', {
        level: level,
        xp: xp

    }).then((response) => {

        callback(response.data)
    })
}

export default getUpgradeGold;