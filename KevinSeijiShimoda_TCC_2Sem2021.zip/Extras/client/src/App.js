import React, { useState } from "react";

import "./App.css";

import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import FormDados from "./components/FormDados/FormDados";
import Result from "./components/Result/Result";
import calculateProbability from "./functions/CalculateProbability";
import getUpgradeGold from "./functions/GetUpgradeGold";
import About from "./components/About/About";
import Infos from "./components/Infos/Infos";

const App = () => {
  const [play1, setPlay1] = useState(0);
  const [play2, setPlay2] = useState(0);
  const [message, setMessage] = useState("");

  const calculate = (cost, wanted, othersChampions, level, xp, gold) => {
    // eslint-disable-next-line
    if (gold != 0) {
      calculateProbability(
        cost,
        wanted,
        othersChampions,
        level,
        gold,
        function (response) {
          setPlay1(response);
        }
      );

      // eslint-disable-next-line
      if (level != 9) {
        getUpgradeGold(level, xp, function (response) {
          if (gold * 1 >= response) {
            setMessage("");
            calculateProbability(
              cost,
              wanted,
              othersChampions,
              Number(level) + 1,
              gold-response,
  
              function (response) {
                setPlay2(response);
              }
            );
  
          } else {
            setMessage("Jogada 2 inválida. Ouro insuficiente para subir de nível.");
          }
        });
      } else {
        setMessage("Jogada 2 inválida. Não é mais possível de subir de nível.");
      }
    }
    else{
      setPlay1(0);
      setPlay2(0);
    }
  };

  const reset = () => {
    setPlay1(0);
    setPlay2(0);

  }

  return (
    <>
      <Header />

      <About/>

      <Infos/>

      <FormDados calculate={calculate} reset={reset}></FormDados>

      <Result play1={play1} play2={play2} message={message} />

      <Footer />
    </>
  );
};

export default App;
