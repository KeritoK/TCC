import React, {useEffect, useState } from 'react';


import Container from 'react-bootstrap/esm/Container';
import Play from '../Play/Play';



const Result = ({ play1, play2, message }) => {
    const [style1, setStyle1] = useState("");
    const [style2, setStyle2] = useState("");
    
    useEffect(() => {

        // eslint-disable-next-line
        if(play1 == play2 && play1 == 0){
            setStyle1("neutro");
            setStyle2("neutro");
        }
        else{
            if(play1 > play2){
            
                setStyle1("maior");
                setStyle2("menor");
            }
            else{
                
                setStyle1("menor");
                setStyle2("maior");
            }
        }
        
        


    }, [play1, play2]);


    return (
        <Container>
            <h1>Resultados</h1>
            <hr />

            <Play play="Jogada 1 - Não subir de nível e usar todo o ouro para atualizar a loja" result={play1} style={style1} ></Play>


            {message === "" ?
                <Play play="Jogada 2 - Subir de nível e, depois, usar todo o ouro para atualizar a loja" result={play2} style={style2}></Play>
                :
                <Container className="mb-5"><h2>{message}</h2></Container>


            }





        </Container >


    )

}

export default Result;
