import React from 'react';

import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';


import './Header.css'

const Header = () => {
    return (
        <Navbar className="header" fixed="top">
            <Container >
                <h1>Sistema de Apoio à Decisão para TeamFight Tactics</h1>

            </Container>


        </Navbar>
    );
}

export default Header;