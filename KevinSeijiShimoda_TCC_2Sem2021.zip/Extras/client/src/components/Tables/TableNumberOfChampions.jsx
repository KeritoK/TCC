import React, {useEffect, useState } from 'react';

import Table from 'react-bootstrap/Table'
import getAllNumberOfChampions from '../../functions/GetAllNumberOfChampions';


import './Table.css'

const TableNumberOfChampions = () => {

    const [allNumberOfChampions, setAllNumberOfChampions] = useState([[0,0,0,0,0], [0,0,0,0,0]]);

    useEffect(() => {

        getAllNumberOfChampions(function(response){
            setAllNumberOfChampions(response);
            

        })
        


    }, []);


    return(
        <Table className="table">
            
            <thead>
                <tr>
                    <th className="first-column">#</th>
                    <th className="other-column">Custo 1</th>
                    <th className="other-column">Custo 2</th>
                    <th className="other-column">Custo 3</th>
                    <th className="other-column">Custo 4</th>
                    <th className="other-column">Custo 5</th>
               
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th className="first-column">Qtd. de Campeões</th>
                    <th className="other-column">{allNumberOfChampions[1][0]}</th>
                    <th className="other-column">{allNumberOfChampions[1][1]}</th>
                    <th className="other-column">{allNumberOfChampions[1][2]}</th>
                    <th className="other-column">{allNumberOfChampions[1][3]}</th>
                    <th className="other-column">{allNumberOfChampions[1][4]}</th>
                </tr>
                <tr>
                    <th className="first-column">Cópias de Cada Campeão</th>
                    <th className="other-column">{allNumberOfChampions[0][0]}</th>
                    <th className="other-column">{allNumberOfChampions[0][1]}</th>
                    <th className="other-column">{allNumberOfChampions[0][2]}</th>
                    <th className="other-column">{allNumberOfChampions[0][3]}</th>
                    <th className="other-column">{allNumberOfChampions[0][4]}</th>
                </tr>
                <tr>
                    <th className="first-column">Total de Cópias</th>
                    <th className="other-column">{allNumberOfChampions[1][0] * allNumberOfChampions[0][0]}</th>
                    <th className="other-column">{allNumberOfChampions[1][1] * allNumberOfChampions[0][1]}</th>
                    <th className="other-column">{allNumberOfChampions[1][2] * allNumberOfChampions[0][2]}</th>
                    <th className="other-column">{allNumberOfChampions[1][3] * allNumberOfChampions[0][3]}</th>
                    <th className="other-column">{allNumberOfChampions[1][4] * allNumberOfChampions[0][4]}</th>
                </tr>

            </tbody>

        </Table>

    )



}

export default TableNumberOfChampions;