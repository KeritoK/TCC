import React, { useEffect, useState } from 'react';

import Table from 'react-bootstrap/Table'
import getAllCostProbabilities from '../../functions/GetAllCostProbabilities';
import getAllExperiences from '../../functions/GetAllExperiences';

import './Table.css'

const TableProbabilities = () => {

    const [costProbabilities, setCostProbabilities] = useState([[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]);
    const [experience, setExperience] = useState([0, 0, 0, 0, 0, 0, 0, 0]);

    useEffect(() => {

        getAllCostProbabilities(function (response) {
            setCostProbabilities(response);

            getAllExperiences(function (response) {
                setExperience(response)

            })

        })



    }, []);


    return (
        <Table className="table">

            <thead>
                <tr>
                    <th className="first-column2">Nível de Jogador</th>
                    <th className="other-column">Experiência</th>
                    <th className="other-column">Custo 1</th>
                    <th className="other-column">Custo 2</th>
                    <th className="other-column">Custo 3</th>
                    <th className="other-column">Custo 4</th>
                    <th className="other-column">Custo 5</th>

                </tr>
            </thead>
            <tbody>
                {experience.map((item, index) => {
                    return (
                        <tr>
                            <th className="first-column2">{index +1}</th>
                            <th className="other-column">{experience[index]}</th>
                            <th className="other-column">{(costProbabilities[index][0] * 100).toFixed(0)}%</th>
                            <th className="other-column">{(costProbabilities[index][1] * 100).toFixed(0)}%</th>
                            <th className="other-column">{(costProbabilities[index][2] * 100).toFixed(0)}%</th>
                            <th className="other-column">{(costProbabilities[index][3] * 100).toFixed(0)}%</th>
                            <th className="other-column">{(costProbabilities[index][4] * 100).toFixed(0)}%</th>
                        </tr>

                    )
                })}



            </tbody>

        </Table>

    )



}

export default TableProbabilities;