import React from "react";

import Container from 'react-bootstrap/esm/Container';

import './About.css'

const About = () => {
    return (
        <Container className="container-about">
            <h1>Sobre</h1>
            <hr />
            <h5 className="about">O Sistema de Apoio à Decisão para TeamFight Tactics é um sistema que irá calcular e comparar a probabilidade de sucesso ao procurar uma cópia do campeão desejado com base nos dados da partida informados para duas jogadas distintas, a primeira seria de usar todo o ouro atualizando a loja e a segunda jogada de subir de nível primeiro e, depois, usar o ouro restante para atualizar a loja.
                Os cálculos são efeitos considerando a probabilidade de se encontrar pelo menos uma cópia gastando todo o ouro disponível e que não será comprado nenhum campeão durante o processo de atualização das lojas.</h5>


        </Container>


    )


}

export default About;