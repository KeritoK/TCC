import React from 'react';
import Container from 'react-bootstrap/esm/Container';


import './Play.css'

const Play = ({ play, result, style }) => {
    return (
        <Container className={style + " mb-5"} >
            <p>{play}</p>
            <p className="play-probability">{result.toFixed(2)}%</p>
            




        </Container>
    )

}

export default Play;