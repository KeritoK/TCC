import React, { useEffect, useState } from 'react';


import Container from 'react-bootstrap/esm/Container';
import Form from 'react-bootstrap/Form'
import Col from 'react-bootstrap/Col'
import Row from 'react-bootstrap/Row'
import Button from 'react-bootstrap/Button'



import './FormDados.css'
import getNumberOfChampions from '../../functions/GetNumberOfChampions';
import getExperience from '../../functions/GetExperience';

const FormDados = ({ calculate, reset }) => {

    const [validated, setValidated] = useState(false);

    const [cost, setCost] = useState(1);
    const [wantedChampion, setWantedChampion] = useState(0);
    const [othersChampions, setOthersChampions] = useState(0);
    const [level, setLevel] = useState(1);
    const [xp, setXp] = useState(0);
    const [gold, setGold] = useState(0);
    const [maxWantedChampion, setMaxWantedChampion] = useState(0);
    const [maxChampions, setMaxChampions] = useState(0);
    const [maxExperience, setMaxExperience] = useState(0);

    useEffect(() => {
        reset();



        // eslint-disable-next-line
    }, [cost, wantedChampion, othersChampions, level, xp, gold]);


    useEffect(() => {

        getNumberOfChampions(cost, function (response) {
            setMaxWantedChampion(response[0]);
            setMaxChampions(response[1] - response[0]);
        });



    }, [cost]);

    useEffect(() => {

        getExperience(level, function (response) {
            setMaxExperience(response);

        });



    }, [level]);


    const handleSubmit = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();

        }
        else {
            calculate(cost, wantedChampion, othersChampions, level, xp, gold);
            event.preventDefault();
            event.stopPropagation();
        }



        setValidated(true);

    };

    return (
        <Container className="mt-4 mb-3">
            <h1>Dados da Partida</h1>
            <hr />
            <Form noValidate validated={validated} onSubmit={handleSubmit}>
                <Row className="mb-1">
                    <Col>
                        <Form.Group >
                            <Form.Label >Custo do Campeão Desejado</Form.Label>
                            <Form.Select onChange={(e) => setCost(e.target.value)}>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>

                    <Col>
                        <Form.Group >
                            <Form.Label>Cópias do Campeão Desejado em Jogo</Form.Label>
                            <Form.Control
                                required
                                type="number" min="0" step="1" max={maxWantedChampion}
                                defaultValue={0}
                                placeholder="Qtd. de Cópias do Campeão Desejado em Jogo"
                                onChange={(e) => setWantedChampion(e.target.value)} />
                            <Form.Control.Feedback type="invalid">
                                Por favor, forneça um valor válido!
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>

                    <Col>
                        <Form.Group  >
                            <Form.Label>Outros Campeões do Mesmo Custo em Jogo</Form.Label>
                            <Form.Control
                                required
                                type="number" min="0" step="1" max={maxChampions}
                                defaultValue={0}
                                placeholder="Qtd. de Outros Campeões do Mesmo Custo em Jogo"
                                onChange={(e) => setOthersChampions(e.target.value)} />
                            <Form.Control.Feedback type="invalid">
                                Por favor, forneça um valor válido!
                            </Form.Control.Feedback>
                            <Form.Text muted>
                                Não contar o campeão desejado
                            </Form.Text>

                        </Form.Group>

                    </Col>

                </Row>

                <Row className="mb-3">
                    <Col>
                        <Form.Group >
                            <Form.Label>Nível de Jogador</Form.Label>
                            <Form.Select onChange={(e) => setLevel(e.target.value)}>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>

                    <Col>
                        <Form.Group >
                            <Form.Label>Experiência Atual</Form.Label>
                            <Form.Control
                                required
                                type="number" min="0" step="2" max={maxExperience}
                                defaultValue={0}
                                placeholder="Qtd. de Experiência Atual"
                                onChange={(e) => setXp(e.target.value)} />
                            <Form.Control.Feedback type="invalid">
                                Por favor, forneça um valor válido!
                            </Form.Control.Feedback>
                        </Form.Group>
                    </Col>

                    <Col>
                        <Form.Group >
                            <Form.Label>Ouro Atual</Form.Label>
                            <Form.Control
                                required
                                type="number" min="0" step="1"
                                defaultValue={0}
                                placeholder="Qtd. de Ouro Atual"
                                onChange={(e) => setGold(e.target.value)} />
                            <Form.Control.Feedback type="invalid">
                                Por favor, forneça um valor válido!
                            </Form.Control.Feedback>

                        </Form.Group>

                    </Col>

                </Row>

                <Button className="btn-calcular" type="submit" xs="auto">
                    <strong>Calcular</strong>
                </Button>


            </Form>
        </Container>

    );
}

export default FormDados;