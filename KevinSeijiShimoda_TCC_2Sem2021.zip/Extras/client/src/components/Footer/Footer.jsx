import React from 'react';

import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';

import './Footer.css'


const Footers = () => {
    return (
        <>
            <Container >
                <hr />
                <Navbar className="footer" >


                    <h5>
                        <strong>Sistema de Apoio à Decisão para TeamFight Tactics</strong> foi criado seguindo a política do “Lenga-Lenga Jurídico” da Riot Games com recursos pertencentes à Riot Games. A Riot Games não endossa ou patrocina este projeto.
                    </h5>



                </Navbar>
            </Container>

        </>
    );
}

export default Footers;