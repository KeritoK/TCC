import React from "react";

import Container from 'react-bootstrap/esm/Container';
import TableNumberOfChampions from "../Tables/TableNumberOfChampions";
import TableProbabilities from "../Tables/TableProbabilities";


const Infos = () => {
    return(
        <Container className="mt-4">
            <h1>Informações do Jogo</h1>
            <hr />

            <TableNumberOfChampions/>
            <TableProbabilities/>
            

        </Container>


    )
}

export default Infos;