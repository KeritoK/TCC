const math = require("mathjs");

const costProbability = require("../datas/CostProbability");

module.exports = function (cost, level, amostral, wanted, group, success){
    let hypergeometric = 0;

    if(amostral-wanted > group-success)
    {
        hypergeometric = (math.combinations(wanted, success) * math.combinations(amostral-wanted, group-success)) / math.combinations(amostral, group);
    }
    else{
        hypergeometric = (math.combinations(wanted, success) * math.combinations(amostral-wanted, amostral-wanted)) / math.combinations(amostral, group);

    }

    return costProbability.costProbability.subset(math.index(level-1, cost-1)) * (1-hypergeometric);

}