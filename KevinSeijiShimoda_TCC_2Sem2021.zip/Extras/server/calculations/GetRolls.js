const math = require("mathjs");

module.exports = function (gold){

    return parseInt(gold/2) 

}