const math = require("mathjs");

const experience = require("../datas/Experience");

module.exports = function (){

    
    return experience;
}