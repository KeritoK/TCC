const math = require("mathjs");



module.exports = function (storeProbability, tries, sucess){

    let binomial = math.combinations(tries, sucess) * math.pow(storeProbability, sucess) * math.pow(1-storeProbability, tries-sucess)
    
    return 1-binomial;

    

}