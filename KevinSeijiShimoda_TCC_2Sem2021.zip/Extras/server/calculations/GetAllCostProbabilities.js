const math = require("mathjs");

const costProbability = require("../datas/CostProbability");

module.exports = function (){

    
    return costProbability;
}