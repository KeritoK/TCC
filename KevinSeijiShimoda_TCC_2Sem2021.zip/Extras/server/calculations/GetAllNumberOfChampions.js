const math = require("mathjs");

const numberOfChampions = require("../datas/NumberOfChampions");

module.exports = function (){

    
    return numberOfChampions;
}