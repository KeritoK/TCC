const math = require("mathjs");

const numberOfChampions = require("../datas/NumberOfChampions");

module.exports = function (cost){

    let totalWantedChampion = numberOfChampions.numberOfChampions.subset(math.index(0,cost-1));
    let totalChampions = (numberOfChampions.numberOfChampions.subset(math.index(0,cost-1)) * numberOfChampions.numberOfChampions.subset(math.index(1,cost-1)));


    return math.matrix([totalWantedChampion, totalChampions]);
}