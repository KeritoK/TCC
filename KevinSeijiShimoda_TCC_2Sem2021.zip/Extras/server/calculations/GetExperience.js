const math = require("mathjs");

const experience = require("../datas/Experience");


module.exports = function (level){

    return math.ceil((experience.experience.subset(math.index(level-1))) ); 
}