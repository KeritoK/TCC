const math = require("mathjs");

const numberOfChampions = require("../datas/NumberOfChampions");

module.exports = function (cost, wantedChampion, othersChampions){
    
    let totalChampions = (numberOfChampions.numberOfChampions.subset(math.index(0,cost-1)) * numberOfChampions.numberOfChampions.subset(math.index(1,cost-1)));
    let amostral = totalChampions - othersChampions - wantedChampion;
    return amostral;
}