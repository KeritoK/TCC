const math = require("mathjs");


const experience = math.matrix(
  [0, 2, 6, 10, 20, 36, 56, 80, 0]

);

module.exports = {
    experience
};