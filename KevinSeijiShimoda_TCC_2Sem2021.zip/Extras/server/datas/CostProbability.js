const math = require("mathjs");


const costProbability = math.matrix([
  [1, 0, 0, 0, 0],              // lvl 1
  [1, 0, 0, 0, 0],              // lvl 2
  [0.75, 0.25, 0, 0, 0],        // lvl 3
  [0.55,0.30,0.15,0,0],         // lvl 4
  [0.45,0.33,0.20,0.02,0],      // lvl 5
  [0.25,0.40,0.30,0.05,0],      // lvl 6
  [0.19,0.30,0.35,0.15,0.01],   // lvl 7
  [0.15,0.20,0.35,0.25,0.05],   // lvl 8
  [0.10,0.15,0.30,0.30,0.15]    // lvl 9
]);

module.exports = {
  costProbability
};
