const math = require("mathjs");


const numberOfChampions = math.matrix([
  [29, 22, 18, 12, 10],         // cards
  [13, 13, 12, 11, 8]           // number of champions of each cost

]);

module.exports = {
    numberOfChampions
};
