const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");

const GetAmostral = require("./calculations/GetAmostral");
const GetWanted = require("./calculations/GetWanted");
const StoreProbability = require("./calculations/StoreProbability");
const RollsProbability = require("./calculations/RollsProbability");
const GetRolls = require("./calculations/GetRolls");
const UpgradeGold = require("./calculations/UpgradeGold");
const GetNumberofChampions = require("./calculations/GetNumberOfChampions");
const GetExperience = require("./calculations/GetExperience");
const GetAllNumberOfChampions = require("./calculations/GetAllNumberofChampions");
const GetAllExperiences = require("./calculations/GetAllExperiences");
const GetAllCostProbabilities = require("./calculations/GetAllCostProbabilities");


app.use(bodyParser.urlencoded({extended:true}))
app.use(cors())
app.use(express.json())

app.get("/", (req, res) => {
  res.send()
});

app.listen(3001, () => {
  console.log("Running on port 3001");
});



app.post("/api/storeProbability", (req, res) => {

  const cost = req.body.cost;
  const level = req.body.level;
  const wantedChampion = req.body.wantedChampion;
  const othersChampions = req.body.othersChampions;

 

  
  let amostral = GetAmostral(cost, wantedChampion, othersChampions) * 1;
  let wanted = GetWanted(cost, wantedChampion) * 1;
  let result = StoreProbability(cost, level, amostral, wanted, 5, 0);

  
  res.send(result.toString())
});



app.post("/api/rollsProbability", (req, res) => {

  const storeProbability = req.body.storeProbability;
  const gold = req.body.gold;

  let tries = GetRolls(gold);

  let result = RollsProbability(storeProbability, tries, 0);


  res.send(result.toString());
});

app.post("/api/upgradeGold", (req, res) => {

  const level = req.body.level;
  const xp = req.body.xp;


  let result = UpgradeGold(level, xp);

  res.send(result.toString());
});


app.post("/api/getNumberOfChampions", (req, res) => {

  const cost = req.body.cost;

  let result = GetNumberofChampions(cost);

  res.send(result.toString());
});

app.post("/api/getExperience", (req, res) => {

  const level = req.body.level;

  let result = GetExperience(level);

  res.send(result.toString());
});

app.get("/api/getAllNumberOfChampions", (req, res) => {

  let result = GetAllNumberOfChampions();

  res.send(result);
});

app.get("/api/getAllExperiences", (req, res) => {

  let result = GetAllExperiences();

  res.send(result);
});

app.get("/api/getAllCostProbabilities", (req, res) => {

  let result = GetAllCostProbabilities();

  res.send(result);
});
